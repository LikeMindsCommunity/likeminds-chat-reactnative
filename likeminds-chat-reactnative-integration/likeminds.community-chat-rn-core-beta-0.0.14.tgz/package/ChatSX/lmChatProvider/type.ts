import { LMChatClient } from "@likeminds.community/chat-rn-beta";;
import React from "react";

export interface LMChatProviderProps {
  myClient: LMChatClient;
  children?: React.ReactNode;
  userName?: string;
  userUniqueId?: string;
  apiKey?: string;
  accessToken?: string;
  refreshToken?: string;
  profileImageUrl?: string;
  lmChatInterface?: any;
  imageUrl?: string;
}

export interface LMChatBotProviderProps {
  myClient: LMChatClient;
  children?: React.ReactNode;
  lmChatInterface?: any;
}
