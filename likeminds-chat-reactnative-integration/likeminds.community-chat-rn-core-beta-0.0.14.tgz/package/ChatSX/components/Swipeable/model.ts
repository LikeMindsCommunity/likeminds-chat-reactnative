import React from "react"
import {Conversation} from '@likeminds.community/chat-rn-beta/shared/responseModels/Conversation';

export interface SwipeableParams {
  onFocusKeyboard: () => void;
  item: Conversation;
  isStateIncluded: boolean;
  children?: React.ReactNode;
}
